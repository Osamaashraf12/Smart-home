import time

import speech_recognition as sr


# Define a function for talking in a separate thread
def talk_threaded(talk):
    talk.talker(talk)


# Initialize the recognizer
mic = sr.Recognizer()

# Use the default microphone as the audio source
with sr.Microphone() as source:

    # Continuously listen for speech input
    while True:
        try:
            mic.energy_threshold = 5000
            # Listen for speech input for a maximum of 2 seconds
            audio = mic.listen(source)
            time.sleep(2)

            # Recognize speech using Google Speech Recognition
            text = mic.recognize_google(audio)

            # Check if the input contains the specific word
            if "hi home" in text.lower():
                import talk
                talk.talker()

        except sr.WaitTimeoutError:
            # No speech detected within 3 seconds
            print("No speech detected within 3 seconds")

        except sr.UnknownValueError:
            # Speech Recognition could not understand audio
            print("Sorry, I could not understand audio")

        except sr.RequestError as e:
            # Could not request results from Google Speech Recognition service
            print("Could not request results; {0}".format(e))
