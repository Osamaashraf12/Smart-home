import cv2
import threading
import pickle
import face_recognition
import time

names = []


def display_camera_stream(name, ip_address):
    # Load the database of known faces
    with open('faces.pkl', 'rb') as f:
        database = pickle.load(f)

    names = []
    start_time = time.time()  # Record the start time
    capture = cv2.VideoCapture(ip_address)  # Use the IP address to access the camera stream

    while True:
        ret, frame = capture.read()
        frame = cv2.flip(frame, 1)

        # Find all the faces in the current frame
        face_locations = face_recognition.face_locations(frame, model='hog')

        # Convert the frame to RGB for face recognition
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        names = []  # List to store recognized names in the current frame

        for top, right, bottom, left in face_locations:
            # Extract the face encoding for the current face
            face_encoding = face_recognition.face_encodings(rgb_frame, [(top, right, bottom, left)])[0]
            for name, encodings in database.items():
                for encoding in encodings:
                    # Compare the distance between the current encoding and the ones in the database
                    distance = face_recognition.face_distance([encoding], face_encoding)[0]

                    # If the distance is below a threshold, we have a match
                    if distance < 0.6:
                        color = (0, 255, 0)  # green
                        names.append(name)  # Add the recognized name to the list

                        if name:
                            message = f"{name} is in the room"
                            color = (0, 255, 0)  # Green color for the message
                        cv2.putText(frame, message, (10, 30), cv2.FONT_HERSHEY_DUPLEX, 0.6, color, 1)
                        start_time = time.time()  # Record the start time
                        break
                else:
                    continue
                break

        # Check if no names are recognized in the current frame
        if not names:
            elapsed_time = int(time.time() - start_time)
            elapsed_time_mm_ss = f"{elapsed_time // 60:02d}:{elapsed_time % 60:02d}"
            message = f"{name} isn't in room for {elapsed_time_mm_ss}"
            color = (0, 0, 255)  # Red color for the message
            cv2.putText(frame, message, (10, 30), cv2.FONT_HERSHEY_DUPLEX, 0.8, color, 1)

        cv2.imshow(f"Video Stream - {ip_address}", frame)

        if cv2.waitKey(1) == ord('q'):
            break

    capture.release()
    cv2.destroyAllWindows()

def run_camera_streams():

    # List of tuples containing streamer names and their IP addresses
    streamers = [
        ('osama', 'http://192.168.43.250:8080')
    ]
    threads = []

    # Create threads for each streamer
    for name, ip_address in streamers:
        thread = threading.Thread(target=display_camera_stream, args=(name, ip_address))
        threads.append(thread)

    # Start all the threads
    for thread in threads:
        thread.start()

    # Wait for all threads to finish
    for thread in threads:
        thread.join()

run_camera_streams()