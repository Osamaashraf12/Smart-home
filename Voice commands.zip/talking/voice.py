import pyttsx3


def talk(name):
    engine = pyttsx3.init()
    engine.setProperty('rate', 160)
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[1].id)
    engine.say(name)
    engine.runAndWait()
