import os
import random
import pygame
import threading

def play(directory):
    mp3_files = os.listdir(directory)

    pygame.mixer.init()
    random_file = random.choice(mp3_files)
    file_path = os.path.join(directory, random_file)
    pygame.mixer.music.load(file_path)
    pygame.mixer.music.set_volume(0.3)
    pygame.mixer.music.play()

def play_music(directory):
    p = threading.Thread(target=play, args=(directory,))
    p.start()