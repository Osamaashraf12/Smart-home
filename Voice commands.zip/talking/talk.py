import time
import threading
import voice
import speech_recognition as sr
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from player import play_music

options = Options()
options.add_experimental_option("detach", True)
options.add_argument("--headless")
service = Service(executable_path=ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=options)


def get_page_thread():
    driver.get('https://new-interface-2171.zapier.app/page')
t = threading.Thread(target=get_page_thread)
t.start()

# Initialize the recognizer
mic = sr.Recognizer()
talking = 3
voice.talk("Hello, how can I help you?")


while True:

    with sr.Microphone() as source:
        mic.energy_threshold = 5000
        # Listen for speech input for a maximum of 2 seconds
        audio = mic.listen(source)
        time.sleep(2)

        try:
            # Recognize speech using Google Speech Recognition
            text = mic.recognize_google(audio)

            # Check if the input contains the specific phrase
            if "open the door" in text.lower():
                voice.talk("door is opening")
                # send_serial_data("o")

            elif "open the light" in text.lower():
                voice.talk("light is opening")
                # send_serial_data("l")

            elif "close the light" in text.lower():
                voice.talk("light is closing")
                # send_serial_data("L")

            elif "ramadan mode" in text.lower():
                play_music("C:\\Users\\osama\\OneDrive\\Desktop\\securitize\\ramadan")

            elif "feast mode" in text.lower():
                # send_serial_data("E")
                play_music("C:\\Users\\osama\\OneDrive\\Desktop\\securitize\\feast")

            elif "show me cameras" in text.lower():
                import cameras

            elif "close" in text.lower():
                voice.talk("Bye bye")
                break
            else:
                # Use the AI chatbot if the command is unspecified
                try:
                    wait = WebDriverWait(driver, 7)
                    typing = wait.until(EC.element_to_be_clickable((By.XPATH, '//*[@id="__next"]/div[1]/div/div/div/div/div/div/div/form/fieldset/textarea')))
                    typing.click()
                    typing.send_keys(text.lower() + Keys.RETURN)
                    element = wait.until(EC.element_to_be_clickable((By.XPATH,f'//*[@id="__next"]/div[1]/div/div/div/div/div/div/div/div/div/div[{talking}]/div[2]/p')))
                    voice.talk(element.text)
                    talking += 2
                except Exception as e:
                    # Handle the case where the element is not found
                    voice.talk('Please, say it again.')

        except sr.WaitTimeoutError:
            # No speech detected within 5 seconds
            print("No speech detected within 5 seconds")

        except sr.UnknownValueError:
            # Speech Recognition could not understand audio
            print("Sorry, I could not understand audio2")

        except sr.RequestError as e:
            # Could not request results from Google Speech Recognition service
            print("Could not request results; {0}".format(e))
