from selenium.webdriver.common.keys import Keys
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager


# Set up the Chrome browser with WebDriver Manager
options = Options()
options.add_experimental_option("detach", True)  # Keep the browser window open after exiting the script
# options.add_argument("--headless")  # Minimize the Chrome window
service = Service(executable_path=ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=options)

# Navigate to the website you want to scrape
driver.get('https://new-interface-2171.zapier.app/page')

n = 1

wait = WebDriverWait(driver, 10)  # Maximum wait time of 10 seconds
element = wait.until(EC.presence_of_element_located((By.XPATH, f'//*[@id="__next"]/div[{n}]/div/div/div/div/div/div/div/div[2]')))
element.click()
element = driver.find_element("xpath", f'//*[@id="__next"]/div[{n}]/div/div/div/div/div/div/div/div[2]')
typing = driver.find_element("xpath", f'//*[@id="__next"]/div[{n}]/div/div/div/div/div/div/form/fieldset/textarea')
typing.click()
typing.send_keys("hi" + Keys.RETURN)

# Print the text of the element
print(element.text)
