import pyttsx3


def talk(name):
    engine = pyttsx3.init()
    engine.setProperty('rate', 160)
    engine.say(f"Welcome {name}")
    engine.runAndWait()
