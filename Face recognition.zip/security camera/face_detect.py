import cv2
import face_recognition
import pickle
import datetime
from telegram import telegram_message
import voice
import threading


# Define a function for talking in a separate thread
def talk_threaded(talk):
    voice.talk(talk)


names = []
# Load the database of known faces
with open('faces.pkl', 'rb') as f:
    database = pickle.load(f)

video_capture = cv2.VideoCapture(0)

while True:

    ret, frame = video_capture.read()
    frame = cv2.flip(frame, 1)

    # Find all the faces in the current frame
    face_locations = face_recognition.face_locations(frame, model='hog')

    # Convert the frame to RGB for face recognition
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    for top, right, bottom, left in face_locations:
        # Extract the face encoding for the current face
        face_encoding = face_recognition.face_encodings(rgb_frame, [(top, right, bottom, left)])[0]
        for name, encodings in database.items():
            for encoding in encodings:
                # Compare the distance between the current encoding and the ones in the database
                distance = face_recognition.face_distance([encoding], face_encoding)[0]

                # If the distance is below a threshold, we have a match
                if distance < 0.6:
                    color = (0, 255, 0)  # green
                    cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_DUPLEX, 0.9, color, 2)
                    if name not in names:
                        names.append(name)
                        time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        telegram_message.send_telegram_message(f"{name} detected at {time}")

                        # Start talking in a separate thread
                        threading.Thread(target=talk_threaded, args=(name,)).start()

                    break
            else:
                continue
            break
        else:
            name = "stranger"
            color = (0, 0, 255)  # red
            cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_DUPLEX, 0.9, color, 2)

            if "stranger" not in names:
                names.append("stranger")
                # Send message to Telegram
                time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                telegram_message.send_telegram_image(f"stranger detected at {time}", frame)

        cv2.rectangle(frame, (left, top), (right, bottom), color, 2)

    cv2.imshow('Video', frame)

    if cv2.waitKey(1) == ord('q'):
        break

video_capture.release()
cv2.destroyAllWindows()
