import os.path
import cv2
import face_recognition
import pickle

video_capture = cv2.VideoCapture(0)

face_encodings_dict = {}

while True:
    # Capture a single frame from the camera
    ret, frame = video_capture.read()
    frame = cv2.flip(frame, 1)

    # Find all the faces in the current frame
    face_locations = face_recognition.face_locations(frame)

    # If a face is found, extract its features
    if len(face_locations) > 0:
        # Extract the features for the face found
        face_encoding = face_recognition.face_encodings(frame, face_locations)

        # Exit the loop if we've captured the encoding for person
        break

    cv2.imshow('Detected Face', frame)
    cv2.waitKey(1)

# Release the camera
video_capture.release()
cv2.destroyAllWindows()

# Prompt the user to enter the name of the person
name = input("Enter the name of the person: ")

# Check if the file exists and load the face encodings dictionary from the file
if os.path.isfile('faces.pkl'):
    with open('faces.pkl', 'rb') as f:
        face_encodings_dict = pickle.load(f)

# Update the face encodings dictionary with the new face encoding and name
face_encodings_dict[name] = face_encoding

# Save the updated face encodings dictionary to the file
with open('faces.pkl', 'wb') as f:
    pickle.dump(face_encodings_dict, f)
