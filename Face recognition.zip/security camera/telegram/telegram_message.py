import cv2
import requests
import os

# Set up Telegram bot
TOKEN = # enter your bot token
chat_id = # enter your bot id


def send_telegram_message(message):
    # Send the message to Telegram
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    data = {"chat_id": chat_id, "text": message}
    response = requests.post(url, data=data)
    # print(response.json()) #to print any comment

def send_telegram_image(message, frame):
    # Save the image as a temporary file
    filename = "temp.jpg"
    cv2.imwrite(filename, frame)

    # Send the message and the captured frame to Telegram
    url = f"https://api.telegram.org/bot{TOKEN}/sendPhoto"
    files = {"photo": open(filename, "rb")}
    data = {"chat_id": chat_id, "caption": message}
    response = requests.post(url, data=data, files=files)
    # print(response.json()) #to print any comment

    # Close the file and remove it
    files["photo"].close()
    os.remove(filename)